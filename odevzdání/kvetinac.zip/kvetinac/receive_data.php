<?php
// Soubor pro ukládání stavu zavlažování
$statusFile = 'irrigation_status.txt';
// Soubor pro ukládání vlhkosti půdy
$dataFile = 'data.txt';

// API pro přepnutí zavlažování
if (isset($_GET['action']) && $_GET['action'] == 'toggle') {
    // Načti aktuální stav
    $status = file_exists($statusFile) ? trim(file_get_contents($statusFile)) : 'OFF';

    // Přepni stav
    $newStatus = ($status === 'ON') ? 'OFF' : 'ON';

    // Ulož nový stav
    file_put_contents($statusFile, $newStatus);

    // Vrátit odpověď
    echo "Zavlažování je nyní: $newStatus";
    exit;
}

// API pro získání stavu zavlažování
if (isset($_GET['action']) && $_GET['action'] == 'get_status') {
    $status = file_exists($statusFile) ? trim(file_get_contents($statusFile)) : 'OFF';
    echo $status;
    exit;
}

// API pro získání poslední hodnoty vlhkosti
if (isset($_GET['action']) && $_GET['action'] == 'get_last_value') {
    header('Content-Type: application/json; charset=UTF-8');
    if (file_exists($dataFile)) {
        $lines = file($dataFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!empty($lines)) {
            $lastLine = end($lines);
            if (preg_match('/^(.*?) - Vlhkost: (\d+)/', $lastLine, $matches)) {
                echo json_encode(['time' => $matches[1], 'value' => (int)$matches[2]]);
                exit;
            }
        }
    }
    echo json_encode(['value' => null]);
    exit;
}

// API pro získání dat pro graf
if (isset($_GET['action']) && $_GET['action'] == 'get_graph_data') {
    header('Content-Type: application/json; charset=UTF-8');
    if (file_exists($dataFile)) {
        $lines = file($dataFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $data = [];
        foreach ($lines as $line) {
            if (preg_match('/^(.*?) - Vlhkost: (\d+)/', $line, $matches)) {
                $data[] = [
                    'time' => $matches[1],
                    'value' => (int)$matches[2]
                ];
            }
        }
        echo json_encode($data);
    } else {
        echo json_encode([]);
    }
    exit;
}

// Pokud je metoda POST (pro odesílání dat ze senzoru)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["soil"])) {
    $soil = intval($_POST["soil"]); // Získání hodnoty vlhkosti
    $entry = date("Y-m-d H:i:s") . " - Vlhkost: " . $soil . "\n";

    // Uložit vlhkost do souboru
    file_put_contents($dataFile, $entry, FILE_APPEND);

    // Vrátit odpověď
    echo "Data uložena: $entry";
    exit;
}

// HTML výstup (pro zobrazení stránky)
header("Content-Type: text/html; charset=UTF-8");
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zavlažování - Květináč</title>
    <!-- Načtení Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<h1>Zavlažování - Květináč</h1>

<!-- Tlačítko pro přepnutí zavlažování -->
<button onclick="toggleIrrigation()">Přepnout zavlažování</button>

<h2>Aktuální měření vlhkosti</h2>
<p id="currentSoilValue">Načítání hodnoty...</p>

<h2>Graf vlhkosti půdy</h2>
<canvas id="soilMoistureChart" width="400" height="200"></canvas>

<script>
    let chart; // Globální proměnná pro graf

    // Funkce pro přepnutí zavlažování
    function toggleIrrigation() {
        fetch('receive_data.php?action=toggle')
            .then(response => response.text())
            .then(data => alert(data)) // Zobrazení stavu zavlažování
            .catch(error => console.error('Chyba při přepnutí zavlažování:', error));
    }

    // Funkce pro načtení aktuální hodnoty vlhkosti
    async function loadCurrentSoilValue() {
        const response = await fetch('receive_data.php?action=get_last_value');
        const data = await response.json();
        if (data.value !== undefined) {
            document.getElementById('currentSoilValue').innerText = `Poslední hodnota: ${data.value}`;
        } else {
            document.getElementById('currentSoilValue').innerText = 'Žádná data.';
        }
    }

    // Funkce pro načtení dat pro graf
    async function loadGraphData() {
        const response = await fetch('receive_data.php?action=get_graph_data');
        return response.json();
    }

    // Inicializace grafu
    async function createChart() {
        const ctx = document.getElementById('soilMoistureChart').getContext('2d');
        const data = await loadGraphData();

        // Připrav data pro Chart.js
        const labels = data.map(item => item.time); // Časy na ose X
        const values = data.map(item => item.value); // Hodnoty vlhkosti na ose Y

        chart = new Chart(ctx, {
            type: 'line', // Typ grafu
            data: {
                labels: labels,
                datasets: [{
                    label: 'Vlhkost půdy',
                    data: values,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Čas'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Hodnota vlhkosti'
                        },
                        min: 0,
                        max: 65535
                    }
                }
            }
        });
    }

    // Funkce pro aktualizaci grafu a hodnoty vlhkosti
    async function updateData() {
        // Načti aktuální hodnotu vlhkosti
        await loadCurrentSoilValue();

        // Načti nová data pro graf
        const response = await fetch('receive_data.php?action=get_graph_data');
        const data = await response.json();

        // Aktualizuj graf
        if (chart) {
            chart.data.labels = data.map(item => item.time); // Časy na ose X
            chart.data.datasets[0].data = data.map(item => item.value); // Hodnoty vlhkosti na ose Y
            chart.update(); // Aktualizuj graf
        }
    }

    // Načti graf a aktuální hodnotu při načtení stránky
    window.onload = function() {
        createChart(); // Vytvoř graf
        loadCurrentSoilValue(); // Načti aktuální hodnotu vlhkosti

        // Nastav pravidelnou aktualizaci dat každých 5 sekund
        setInterval(updateData, 5000);
    };
</script>

</body>
</html>